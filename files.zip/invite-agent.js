// api/invite-agent.js — Inviter un agent via Supabase Admin
export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') return res.status(200).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  const SERVICE_KEY = process.env.SUPABASE_SERVICE_KEY;
  const SUPA_URL = 'https://omkmmlbdkzhorrrbeabm.supabase.co';

  if (!SERVICE_KEY) return res.status(500).json({ error: 'SUPABASE_SERVICE_KEY non configuré' });

  try {
    const { nom, email } = req.body;
    if (!nom || !email) return res.status(400).json({ error: 'Nom et email requis' });

    // 1. Inviter l'utilisateur via Supabase Admin API
    const inviteRes = await fetch(`${SUPA_URL}/auth/v1/invite`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'apikey': SERVICE_KEY,
        'Authorization': 'Bearer ' + SERVICE_KEY
      },
      body: JSON.stringify({
        email,
        data: { nom, role: 'agent' }
      })
    });

    const inviteData = await inviteRes.json();
    if (inviteData.error) return res.status(400).json({ error: inviteData.error.message || inviteData.error });

    const userId = inviteData.id;

    // 2. Enregistrer dans la table utilisateurs
    const sbRes = await fetch(`${SUPA_URL}/rest/v1/utilisateurs`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'apikey': SERVICE_KEY,
        'Authorization': 'Bearer ' + SERVICE_KEY,
        'Prefer': 'return=minimal'
      },
      body: JSON.stringify({ id: userId, nom, email, role: 'agent', statut: 'actif' })
    });

    if (!sbRes.ok) {
      const err = await sbRes.text();
      console.error('Insert utilisateur error:', err);
    }

    return res.status(200).json({ success: true, message: 'Invitation envoyée à ' + email });

  } catch (error) {
    console.error('Invite error:', error);
    return res.status(500).json({ error: error.message });
  }
}
