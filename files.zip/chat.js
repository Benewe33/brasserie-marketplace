// api/chat.js — Proxy OpenRouter (modèles gratuits)
export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') return res.status(200).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  const API_KEY = process.env.ANTHROPIC_API_KEY; // on réutilise la même variable
  if (!API_KEY) return res.status(500).json({ error: 'API key not configured' });

  try {
    // Extraire les messages et le système du body
    const { messages, system, max_tokens } = req.body;

    // Convertir le format Anthropic → OpenRouter
    const openRouterMessages = [];
    if (system) {
      openRouterMessages.push({ role: 'system', content: system });
    }
    for (const m of (messages || [])) {
      if (typeof m.content === 'string') {
        openRouterMessages.push({ role: m.role, content: m.content });
      } else if (Array.isArray(m.content)) {
        // Extraire juste le texte des blocs complexes
        const text = m.content.filter(b => b.type === 'text').map(b => b.text).join('\n');
        if (text) openRouterMessages.push({ role: m.role, content: text });
      }
    }

    const response = await fetch('https://openrouter.ai/api/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + API_KEY,
        'HTTP-Referer': 'https://brasserie-marketplace.vercel.app',
        'X-Title': 'Yeye Market Assistant'
      },
      body: JSON.stringify({
        model: 'mistralai/mistral-7b-instruct:free', // modèle 100% gratuit
        max_tokens: max_tokens || 1000,
        messages: openRouterMessages
      })
    });

    const data = await response.json();

    if (data.error) return res.status(500).json({ error: data.error.message });

    // Convertir réponse OpenRouter → format Anthropic
    const text = data.choices?.[0]?.message?.content || '';
    return res.status(200).json({
      content: [{ type: 'text', text }],
      stop_reason: 'end_turn'
    });

  } catch (error) {
    console.error('Proxy error:', error);
    return res.status(500).json({ error: error.message });
  }
}
