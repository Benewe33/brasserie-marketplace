// Service Worker — Yéyé Market PWA
const CACHE = 'yeye-v1';
const STATIC = [
  '/',
  '/index.html',
  '/assistant.html'
];

// Installation — cache les fichiers essentiels
self.addEventListener('install', e => {
  e.waitUntil(
    caches.open(CACHE).then(c => c.addAll(STATIC)).catch(() => {})
  );
  self.skipWaiting();
});

// Activation — nettoyer les anciens caches
self.addEventListener('activate', e => {
  e.waitUntil(
    caches.keys().then(keys =>
      Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k)))
    )
  );
  self.clients.claim();
});

// Fetch — network first, cache fallback
self.addEventListener('fetch', e => {
  // Ne pas cacher les requêtes Supabase ou API
  if (e.request.url.includes('supabase') || 
      e.request.url.includes('api.groq') ||
      e.request.url.includes('kkiapay')) {
    return;
  }

  e.respondWith(
    fetch(e.request)
      .then(res => {
        // Mettre en cache les nouvelles ressources statiques
        if (res.ok && e.request.method === 'GET') {
          const clone = res.clone();
          caches.open(CACHE).then(c => c.put(e.request, clone));
        }
        return res;
      })
      .catch(() => caches.match(e.request))
  );
});

// Push notifications
self.addEventListener('push', e => {
  const data = e.data?.json() || {};
  e.waitUntil(
    self.registration.showNotification(data.titre || 'Yéyé Market', {
      body: data.message || 'Vous avez une nouvelle notification',
      icon: 'https://omkmmlbdkzhorrrbeabm.supabase.co/storage/v1/object/public/avatars/yeye-logo-transparent.png',
      badge: 'https://omkmmlbdkzhorrrbeabm.supabase.co/storage/v1/object/public/avatars/yeye-logo-transparent.png',
      vibrate: [200, 100, 200],
      data: { url: '/' }
    })
  );
});

self.addEventListener('notificationclick', e => {
  e.notification.close();
  e.waitUntil(clients.openWindow(e.notification.data?.url || '/'));
});
